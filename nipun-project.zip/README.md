## How to run scss?
Navigate root folder and run the following commands

    npm install
    npm start

Happy Hacking!
